Bugfix: Fix behavior for foobar (in the present tense, max length 80 chars)

We've fixed the behavior for foobar, a long-standing annoyance for ownCloud
users.

The text in the paragraphs is written in past tense. The last section is a list
of issue URLs, PR URLs and other URLs. The first issue ID (or the first PR ID,
in case there aren't any issue links) is used as the primary ID.

https://github.com/owncloud/android/issues/1234
https://github.com/owncloud/android/pull/55555
https://doc.owncloud.com/server/admin_manual/configuration/server/config_sample_php_parameters.html