package com.owncloud.android.presentation.security.passcode

enum class PasscodeAction {
    CHECK,
    REMOVE,
    CREATE
}
