package com.owncloud.android.presentation.security.passcode

enum class PasscodeType {
    OK,
    ERROR,
    MIGRATION,
    CONFIRM,
    NO_CONFIRM
}
