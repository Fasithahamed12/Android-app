package com.owncloud.android.presentation.security.passcode

data class Status(
    val action: PasscodeAction,
    val type: PasscodeType
)
